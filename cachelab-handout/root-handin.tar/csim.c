#include "cachelab.h"

int main()
{
    int hits = 9;
    int misses = 8;
    int evicts = 6;
    printSummary(hits, misses, evicts);
    return 0;
}
